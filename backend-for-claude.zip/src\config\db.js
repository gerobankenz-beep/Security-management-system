// One shared connection pool to PostgreSQL.
const { Pool, types } = require('pg');
const env = require('./env');

// By default pg returns NUMERIC (type 1700) and BIGINT (type 20) as strings.
// Convert them to JavaScript numbers so latitude, counts and ids behave as expected.
types.setTypeParser(1700, (value) => parseFloat(value));
types.setTypeParser(20, (value) => parseInt(value, 10));
// DATE columns stay plain 'YYYY-MM-DD' strings. (By default pg turns them into Dates in the computer's time zone, which causes off-by-one-day bugs.)
types.setTypeParser(1082, (value) => value);

const pool = new Pool({
  connectionString: env.databaseUrl,
  ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: false } : undefined,
  max: process.env.VERCEL ? 3 : 10,   // serverless: keep connections few
});

// Always use placeholders ($1, $2 ...) for values. Never build SQL by joining strings,
// otherwise attackers can inject their own SQL.
function query(text, params) {
  return pool.query(text, params);
}

module.exports = { pool, query };
