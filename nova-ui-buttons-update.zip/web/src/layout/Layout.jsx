import { useEffect, useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, Building2, ShieldCheck, Briefcase, CalendarDays, ClipboardCheck, Flag,
  TriangleAlert, ChartColumn, Wallet, Users, ScrollText, Settings, LogOut, Circle, Menu, X,
} from 'lucide-react';
import { useAuth } from '../auth/AuthContext';
import { NAV_ITEMS, ROLES } from '../auth/roles';
import { USE_MOCKS } from '../api/client';
import { APP_NAME } from '../brand';
import Logo from '../components/Logo';
import OfflineBanner from '../components/OfflineBanner';
import NotificationBell from '../components/NotificationBell';

// Menu icons, matched by route so roles.js stays a plain list.
const ICONS = {
  '/': LayoutDashboard, '/sites': Building2, '/guards': ShieldCheck, '/clients': Briefcase, '/rosters': CalendarDays,
  '/attendance': ClipboardCheck, '/flags': Flag, '/incidents': TriangleAlert, '/reports': ChartColumn,
  '/payroll': Wallet, '/users': Users, '/audit-logs': ScrollText, '/settings': Settings,
};

const initials = (name = '') => name.split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join('') || '?';
const today = () => new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'Africa/Kampala' });

export default function Layout() {
  const { user, logout } = useAuth();
  const items = NAV_ITEMS.filter((item) => item.roles.includes(user.role));
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  // On phones the menu slides in; close it after every page change.
  useEffect(() => { setMenuOpen(false); }, [location.pathname]);

  return (
    <div className={menuOpen ? 'shell menu-open' : 'shell'}>
      <aside className="sidebar" id="main-menu">
        <div className="brand">
          <Logo />
          <div className="brand-name"><span>The Nova</span>{' '}<span>Protective Systems</span></div>
          <button type="button" className="menu-close" aria-label="Close menu" onClick={() => setMenuOpen(false)}><X size={20} aria-hidden="true" /></button>
        </div>
        <nav aria-label="Main">
          {items.map((item) => {
            const Icon = ICONS[item.to] || Circle;
            return (
              <NavLink key={item.to} to={item.to} end={item.to === '/'} className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}>
                <Icon className="icon" size={19} strokeWidth={1.9} aria-hidden="true" />
                {item.label}
              </NavLink>
            );
          })}
        </nav>
      </aside>
      <button type="button" className="scrim" aria-label="Close menu" tabIndex={-1} onClick={() => setMenuOpen(false)} />
      <div className="main">
        <header className="topbar">
          <div className="topbar-left">
            <button type="button" className="menu-btn" aria-label="Open menu" aria-expanded={menuOpen} aria-controls="main-menu" onClick={() => setMenuOpen(true)}>
              <Menu size={20} aria-hidden="true" />
            </button>
            <div className="topbar-date" title={APP_NAME}>
              {USE_MOCKS ? <span className="badge badge-warn">Mock data</span> : today()}
            </div>
          </div>
          <div className="user-box">
            <NotificationBell />
            <div className="user-chip">
              <span className="avatar" aria-hidden="true">{initials(user.full_name)}</span>
              <span className="user-meta">
                <span className="user-name">{user.full_name}</span>
                <span className="user-role">{ROLES[user.role] || user.role}</span>
              </span>
            </div>
            <button type="button" className="btn btn-logout" aria-label="Log out" onClick={logout}><LogOut size={16} aria-hidden="true" /><span>Log out</span></button>
          </div>
        </header>
        <OfflineBanner />
        <main className="content"><Outlet /></main>
      </div>
    </div>
  );
}
